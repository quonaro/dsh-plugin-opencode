import Schema from "@deepseek-ai/schemastery";
import { Context, Volatile } from "@deepseek-ai/cordis";
//#region node_modules/.pnpm/@deepseek-ai+cosmokit@1.8.5/node_modules/@deepseek-ai/cosmokit/lib/types/misc.d.ts
/** String/symbol keyed dictionary type. */
type Dict<T = any, K extends string | symbol = string> = { [key in K]: T; };
//#endregion
//#region src/provider.d.ts
/** Plugin name; the cordis.patch.yml row uses the `@quonaro/dsh-plugin-opencode/provider` specifier. */
declare const name = "@quonaro/dsh-plugin-opencode/provider";
/** Services this plugin needs: the llm adapter registry and a subprocess provider. */
declare const inject: string[];
/** Plugin configuration; every field is a Volatile re-read at each call. */
interface Config {
  /** Path or PATH-resolved name of the opencode executable. */
  opencodePath: Volatile<string>;
  /** `--auto`: auto-approve permissions not explicitly denied. Headless runs cannot answer prompts. */
  auto: Volatile<boolean>;
  /** `--attach` a running `opencode serve` URL instead of a local instance. */
  attach: Volatile<string>;
  /** `--pure`: run without external opencode plugins. */
  pure: Volatile<boolean>;
  /** Working directory for every spawned session; empty = the harness cwd. */
  cwd: Volatile<string>;
  /** Cooperative timeout in milliseconds per generation. OpenCode runs are slow. */
  timeoutMs: Volatile<number>;
  /** In-memory cap for the captured stderr tail surfaced on failure. */
  stderrMaxBytes: Volatile<number>;
  /** Environment variable names forwarded to the opencode child process. */
  forwardEnv: Volatile<string[]>;
  /** Extra CLI flags appended verbatim before the prompt. */
  extraArgs: Volatile<string[]>;
  /**
   * Advertised models, in selector order. `id` is the route model id passed via
   * GenerateOptions.model; `opencodeModel` is the `-m` value in provider/model
   * form ('' = the agent's configured default); `name` is the display name in
   * the model selector.
   */
  models: Volatile<{
    id: string;
    opencodeModel: string;
    name: string;
  }[]>;
  /**
   * Instruction prepended to every flattened transcript, telling OpenCode it
   * runs as a model backend and must finish autonomously.
   */
  brief: Volatile<string>;
  /** Answer session-title requests locally instead of spending an OpenCode run on them. */
  localSessionTitles: Volatile<boolean>;
  /** Probe `opencode acp` for the agent's real model catalog instead of using the static `models` table. */
  autoDiscoverModels: Volatile<boolean>;
  /** Timeout for one ACP discovery probe (initialize + session/new). */
  discoveryTimeoutMs: Volatile<number>;
  /** How long a successful discovery result is cached before re-probing. */
  discoveryCacheMs: Volatile<number>;
}
/** Schemastery schema: defaults live here; cordis.yml and GUI edits are validated against it. */
declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
  opencodePath: Schema<string, string, "volatile-defined">;
  auto: Schema<boolean, boolean, "volatile-defined">;
  attach: Schema<string, string, "volatile-defined">;
  pure: Schema<boolean, boolean, "volatile-defined">;
  cwd: Schema<string, string, "volatile-defined">;
  timeoutMs: Schema<number, number, "volatile-defined">;
  stderrMaxBytes: Schema<number, number, "volatile-defined">;
  forwardEnv: Schema<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  extraArgs: Schema<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  models: Schema<NoInfer<({
    id?: string | null;
    opencodeModel?: string | null;
    name?: string | null;
  } & Dict)[]>, NoInfer<Schemastery.ObjectT<NoInfer<{
    id: Schema<string, string, "plain">;
    opencodeModel: Schema<string, string, "defined">;
    name: Schema<string, string, "defined">;
  }>>[]>, "volatile-defined">;
  brief: Schema<string, string, "volatile-defined">;
  localSessionTitles: Schema<boolean, boolean, "volatile-defined">;
  autoDiscoverModels: Schema<boolean, boolean, "volatile-defined">;
  discoveryTimeoutMs: Schema<number, number, "volatile-defined">;
  discoveryCacheMs: Schema<number, number, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
  opencodePath: Schema<string, string, "volatile-defined">;
  auto: Schema<boolean, boolean, "volatile-defined">;
  attach: Schema<string, string, "volatile-defined">;
  pure: Schema<boolean, boolean, "volatile-defined">;
  cwd: Schema<string, string, "volatile-defined">;
  timeoutMs: Schema<number, number, "volatile-defined">;
  stderrMaxBytes: Schema<number, number, "volatile-defined">;
  forwardEnv: Schema<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  extraArgs: Schema<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  models: Schema<NoInfer<({
    id?: string | null;
    opencodeModel?: string | null;
    name?: string | null;
  } & Dict)[]>, NoInfer<Schemastery.ObjectT<NoInfer<{
    id: Schema<string, string, "plain">;
    opencodeModel: Schema<string, string, "defined">;
    name: Schema<string, string, "defined">;
  }>>[]>, "volatile-defined">;
  brief: Schema<string, string, "volatile-defined">;
  localSessionTitles: Schema<boolean, boolean, "volatile-defined">;
  autoDiscoverModels: Schema<boolean, boolean, "volatile-defined">;
  discoveryTimeoutMs: Schema<number, number, "volatile-defined">;
  discoveryCacheMs: Schema<number, number, "volatile-defined">;
}>>, "plain">;
/**
 * Plugin body: register the `opencode` provider route and declare it in the
 * configurable-provider directory so the web Models page can see it.
 */
declare function apply(ctx: Context, config: Config): void;
//#endregion
export { Config, type Dict, apply, inject, name };