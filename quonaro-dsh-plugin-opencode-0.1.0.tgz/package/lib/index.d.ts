import Schema from "@deepseek-ai/schemastery";
import { Context, Volatile } from "@deepseek-ai/cordis";
//#region src/index.d.ts
/** Host plugin name; must match package.json `name` and the cordis.patch.yml row id. */
declare const name = "@quonaro/dsh-plugin-opencode";
/** Services this plugin needs before it loads: the tool registry and a subprocess provider. */
declare const inject: string[];
/** Plugin configuration; every field is a Volatile re-read at each call. */
interface Config {
  /** Path or PATH-resolved name of the opencode executable. */
  opencodePath: Volatile<string>;
  /** `--auto`: auto-approve permissions not explicitly denied. Headless runs cannot answer prompts. */
  auto: Volatile<boolean>;
  /** Default `-m provider/model`; empty string means the opencode config default. */
  model: Volatile<string>;
  /** Default `--agent`; empty string means the default agent. */
  agent: Volatile<string>;
  /** `--attach` a running `opencode serve` URL instead of a local instance. */
  attach: Volatile<string>;
  /** `--pure`: run without external opencode plugins. */
  pure: Volatile<boolean>;
  /** Cooperative timeout in milliseconds for one delegation call. */
  timeoutMs: Volatile<number>;
  /** In-memory cap per captured stream; overflow keeps the tail. */
  maxOutputBytes: Volatile<number>;
  /** Environment variable names forwarded to the opencode child process. */
  forwardEnv: Volatile<string[]>;
  /** Extra CLI flags appended verbatim before the prompt. */
  extraArgs: Volatile<string[]>;
}
/** Schemastery schema: defaults live here; cordis.yml and GUI edits are validated against it. */
declare const Config: Schema<Schemastery.ObjectS<NoInfer<{
  opencodePath: Schema<string, string, "volatile-defined">;
  auto: Schema<boolean, boolean, "volatile-defined">;
  model: Schema<string, string, "volatile-defined">;
  agent: Schema<string, string, "volatile-defined">;
  attach: Schema<string, string, "volatile-defined">;
  pure: Schema<boolean, boolean, "volatile-defined">;
  timeoutMs: Schema<number, number, "volatile-defined">;
  maxOutputBytes: Schema<number, number, "volatile-defined">;
  forwardEnv: Schema<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  extraArgs: Schema<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
  opencodePath: Schema<string, string, "volatile-defined">;
  auto: Schema<boolean, boolean, "volatile-defined">;
  model: Schema<string, string, "volatile-defined">;
  agent: Schema<string, string, "volatile-defined">;
  attach: Schema<string, string, "volatile-defined">;
  pure: Schema<boolean, boolean, "volatile-defined">;
  timeoutMs: Schema<number, number, "volatile-defined">;
  maxOutputBytes: Schema<number, number, "volatile-defined">;
  forwardEnv: Schema<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
  extraArgs: Schema<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
}>>, "plain">;
/** /opencode command payload shape (minimal subset of dsh-commands CommandInvocation). */
interface OpencodeCommandInvocation {
  readonly rawInput: string;
}
interface OpencodeCommandResult {
  kind: 'success' | 'error';
  text?: string;
}
interface OpencodeCommandsLike {
  register(definition: {
    readonly name: string;
    readonly description: string;
    readonly handler: (invocation: OpencodeCommandInvocation) => OpencodeCommandResult | Promise<OpencodeCommandResult>;
  }): unknown;
}
declare module '@deepseek-ai/cordis' {
  interface Context {
    /** Command registry (provided at runtime by @deepseek-ai/dsh-commands, optional). */
    commands: OpencodeCommandsLike;
  }
}
/**
 * Plugin body: register the `opencode` tool, and `/opencode` when a commands
 * service is composed. All registrations are effects — unloading the plugin
 * reverts them automatically.
 */
declare function apply(ctx: Context, config: Config): void;
//#endregion
export { Config, apply, inject, name };